#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/vec_swizzle.hpp>

int main()
{
	int Error = 0;


	return Error;
}

